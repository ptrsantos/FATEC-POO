/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_poo;
import java.text.ParseException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.dao.PedidoDAO;
import model.dao.ProdutoDAO;
import model.entidades.Pedido;
import model.entidades.Produto;
        


public class Trabalho_POO {

    public static void main(String[] args) {
        Pedido pedido = new Pedido();
        PedidoDAO pedDao = new PedidoDAO();
        
        //SimpleDateFormat formatBrasil = new SimpleDateFormat("dd/MM/yyyy");
        //Date dataAtual = new Date();
        //System.out.println(formatBrasil.format(dataAtual));
        
        String niver = "20/12/1970";
        /*try {
            Date meuNiver = (Date) formatBrasil.parse(niver);
            System.out.println(formatBrasil.format(meuNiver));
        } catch (ParseException ex) {
            Logger.getLogger(Trabalho_POO.class.getName()).log(Level.SEVERE, null, ex);
        }*/
        
        /*String dataString = "20-12-1970";
        DateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");
        try {
            java.sql.Date data = new java.sql.Date(fmt.parse(dataString).getTime());
            pedido.setData(data);
            System.out.println("Imprimindo data inserida na tabela " + fmt.format(data));
        } catch (ParseException ex) {
            Logger.getLogger(Trabalho_POO.class.getName()).log(Level.SEVERE, null, ex);
        }
        pedido.setCodCliente(62);
        pedido.setQuantidade(8);
        
        pedDao.inserirPedido(pedido);*/
        
        Produto p = new Produto("Alicate", 15.00);
        ProdutoDAO dao = new ProdutoDAO();
        //ao.inserirProduto(p);
        
        System.out.println(dao.listarProduto());
        
        
        
    }
    
}
