
package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.conexao.Conexao;
import model.entidades.Produto;


public class ProdutoDAO {
    
    private Connection con = null;
    private PreparedStatement pstm = null;
    private ResultSet rs = null;
    private ArrayList<Produto> produtos = null;
    
   
    public boolean inserirProduto(Produto produto){
        String sql ="INSERT INTO Produto(nome, valor) VALUES(?,?)";
        con = Conexao.iniciarConexao();
        try {
            pstm =  con.prepareStatement(sql);
            pstm.setString(1, produto.getNomeProduto());
            pstm.setDouble(2, produto.getValor());
            pstm.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
            return false;
        }finally{
            Conexao.fecharConexao(con, pstm);
        }
    }
    
    public void excluirProduto(int id){
        String sql ="DELETE FROM Produto WHERE id = ?";
        con = Conexao.iniciarConexao();
        try {
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, id);
            pstm.executeUpdate();
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        } finally{
            Conexao.fecharConexao(con, pstm);
        }
    }
    
    public void alterarProduto(Produto produto){
        String sql ="UPDATE Produto SET nome = ?, Valor = ? WHERE Id_Produto = ?";
        con = Conexao.iniciarConexao();
        try {
            pstm = con.prepareStatement(sql);
            pstm.setString(1, produto.getNomeProduto());
            pstm.setDouble(2, produto.getValor());
            pstm.setInt(3, produto.getIdProduto());
            pstm.executeUpdate();
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        } finally{
            Conexao.fecharConexao(con, pstm);
        }
        
    }
    
    public ArrayList<Produto> listarProduto(){
        String sql ="SELECT * FROM Produto";
        con = Conexao.iniciarConexao();
        try {
            
            pstm =  con.prepareStatement(sql);
            rs = pstm.executeQuery();
            while(rs.next()){
                Produto produto  = new Produto();
                
                //produto.setIdProduto(rs.getInt("Id_Produto"));
                System.out.println(rs.getInt("Id_Produto"));
                
                //produto.setNomeProduto(rs.getString("Nome"));
                System.out.println(rs.getString("Nome"));
                
                //produto.setValor(rs.getDouble("Valor"));
                //System.out.println(rs.getDouble("Valor"));
               
                produtos.add(produto);
            }
            Conexao.fecharConexao(con, pstm);
            return produtos;
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
            Conexao.fecharConexao(con, pstm);
            return null;
        } 
    }
    
}
