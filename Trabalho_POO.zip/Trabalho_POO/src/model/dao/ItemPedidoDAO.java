
package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.conexao.Conexao;
import model.entidades.Pedido;
import model.entidades.Produto;

public class ItemPedidoDAO {
    private Connection con = null;
    private PreparedStatement pstm = null;
    private ResultSet rs = null;
    private ArrayList<Produto> produtos = null;
    private Pedido pedido;
    
        public void inserirItemPedido(Pedido pedido, ArrayList<Produto> produtos){
            int tamanho = produtos.size();
                
            if(tamanho >0){
                con = Conexao.iniciarConexao();
                for(int i =0; i< produtos.size(); i++){
                    String sql ="INSERT INTO ItemPedido(Cod_Pedido, Cod_Produto) VALUES(?,?)";
                    try {
                    pstm =  con.prepareStatement(sql);
                    pstm.setInt(1, pedido.getIdPedido());
                    pstm.setInt(2, produtos.get(i).getIdProduto());
                    pstm.executeUpdate();
                    } catch (SQLException ex) {
                    System.err.println(ex.getMessage());
                  }
                }  
                    Conexao.fecharConexao(con, pstm);
                    
            
            }
        }
}
