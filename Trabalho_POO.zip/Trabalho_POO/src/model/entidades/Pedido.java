
package model.entidades;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import model.entidades.Produto;

public class Pedido {
    
    private int idPedido;
    private int codCliente;
    private int quantidade;
    private Date data;
    private Calendar hoje;
    private ArrayList<Produto> produtos;

    public Pedido() {
    }

    public Pedido(int codCliente, int quantidade, Date data, Produto produto) {
        this.codCliente = codCliente;
        this.quantidade = quantidade;
        this.data = data;
        this.produtos.add(produto);
    }

    public void adicionaProduto(Produto produto){
        produtos.add(produto);
    }
    
    public ArrayList<Produto> retornaListaProdutos(){
        return this.produtos;
    }
    
    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(int codCliente) {
        this.codCliente = codCliente;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Calendar getHoje() {
        return hoje;
    }

    public void setHoje(Calendar hoje) {
        this.hoje = hoje;
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(ArrayList<Produto> produtos) {
        this.produtos = produtos;
    }

    public void setData(String data) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    

    
}
