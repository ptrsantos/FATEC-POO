
package model.entidades;

import java.util.ArrayList;

public class ItemPedido {
    private ArrayList<Produto> produtos;
    private Pedido pedido;

    public ItemPedido() {
    }

    public ItemPedido(ArrayList<Produto> produtos, Pedido pedido) {
        this.produtos = produtos;
        this.pedido = pedido;
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(Produto produto) {
        this.produtos.add(produto);
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }
    
    
    
}
